import React from 'react';

const Vision: React.FC = () => {
  const pillars = ['DESIGN', 'DEVELOP', 'DEPLOY', 'DOMINATE'];

  return (
    <section id="vision" className="border-b-4 border-black bg-white py-24 px-6 md:px-12">
      <div className="mx-auto max-w-7xl flex flex-col lg:flex-row gap-16 lg:gap-32 items-start">
        
        {/* Left Column: Stacked Title with Border */}
        {/* Fixed width for the title block to prevent it from feeling "clumsy" or shifting */}
        <div className="flex-shrink-0 flex">
           {/* Thick Orange Left Bar */}
           <div className="w-4 md:w-6 bg-[#ff6600] flex-shrink-0 mr-6 md:mr-8 min-h-full"></div>
           
           <div className="flex flex-col justify-center py-1">
             <span className="brand-font text-2xl md:text-3xl font-black uppercase tracking-[0.2em] text-black leading-none mb-0">
               THE
             </span>
             <h2 className="brand-font text-8xl md:text-9xl lg:text-[10rem] font-black uppercase leading-[0.8] text-black tracking-tighter -ml-1">
               VISION
             </h2>
           </div>
        </div>

        {/* Right Column: Content */}
        <div className="flex-1 flex flex-col pt-4">
          <h3 className="mb-8 brand-font text-5xl md:text-6xl font-black uppercase leading-none tracking-tight">
            CALCULATED <br className="hidden md:block"/> <span className="text-[#ff6600]">CREATIVITY</span>
          </h3>
          
          <p className="mb-12 max-w-xl text-lg md:text-xl font-medium leading-relaxed text-gray-800">
            K-Mean Studio sits at the intersection of raw data and visual storytelling. We believe that the most powerful user experiences are those that strip away the unnecessary, leaving only the essential core.
            <br /><br />
            Inspired by the stark contrasts of industrial design and manga, we build web applications that are bold, fast, and unapologetically direct.
          </p>

          {/* Wide Rectangular Buttons Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full">
            {pillars.map((pillar) => (
              <div 
                key={pillar}
                className="group relative border-2 border-black bg-white py-4 px-2 text-center transition-colors duration-300 hover:bg-black cursor-default"
              >
                <span className="brand-font text-base font-bold uppercase tracking-widest text-black group-hover:text-white transition-colors">
                  {pillar}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Vision;
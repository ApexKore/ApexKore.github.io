import React, { useState, useEffect } from 'react';
import { Github, Mail, Scale, Activity, Globe } from 'lucide-react';
import { NAV_LINKS } from '../constants';

const Footer: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const slides = [
    {
      icon: <Scale className="h-5 w-5" />,
      title: "OPEN SOURCE",
      content: (
        <>
          This project is open sourced under the <span className="text-white font-bold">MIT License</span>. 
          <br/>
          Free to use, modify, and distribute with proper attribution.
        </>
      )
    },
    {
      icon: <Activity className="h-5 w-5" />,
      title: "SYSTEM STATUS",
      content: (
        <>
          All systems operational. <span className="text-white font-bold">100% Uptime</span>.
          <br/>
          Latency: 12ms. Running on edge network.
        </>
      )
    },
    {
      icon: <Globe className="h-5 w-5" />,
      title: "GLOBAL",
      content: (
        <>
          Established 2024. <span className="text-white font-bold">Worldwide Operation</span>.
          <br/>
          Designing for the future, deployed everywhere.
        </>
      )
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      // Fade out
      setIsVisible(false);

      // Wait for fade out to complete before switching content
      setTimeout(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length);
        setIsVisible(true); // Fade back in
      }, 500); // Match CSS duration
    }, 3500); // 3s view time + 0.5s transition

    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <footer id="contact" className="bg-black px-6 pt-24 pb-12 text-white border-t-4 border-[#ff6600]">
      <div className="mx-auto max-w-7xl">
        {/* Main Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 mb-24 items-start">
          
          {/* Column 1: Brand Identity (Reverted to Text Style) */}
          <div className="flex flex-col gap-6 lg:pr-8">
            <h2 className="brand-font text-5xl font-black text-[#ff6600] uppercase tracking-tighter leading-none">
              K-MEAN<br/>STUDIO
            </h2>
            <p className="text-gray-400 font-mono text-sm leading-relaxed max-w-xs border-l-2 border-gray-700 pl-4">
              Engineering digital experiences with precision and impact.
            </p>
          </div>

          {/* Column 2: Explore (Sitemap) */}
          <div className="flex flex-col gap-8 lg:px-4">
            <div className="flex items-center gap-2 mb-2">
               <div className="h-1 w-6 bg-white"></div>
               <span className="text-xs font-bold uppercase tracking-widest text-gray-500">Explore</span>
            </div>
            
            <div className="flex flex-col gap-4">
              {NAV_LINKS.map((link) => (
                <a 
                  key={link.label}
                  href={link.href} 
                  className="group flex items-center gap-2 text-white hover:text-[#ff6600] transition-colors"
                >
                  <span className="brand-font font-bold uppercase tracking-wider text-lg">{link.label}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Column 3: Connect */}
          <div className="flex flex-col gap-8 lg:px-4">
            <div className="flex items-center gap-2 mb-2">
               <div className="h-1 w-6 bg-white"></div>
               <span className="text-xs font-bold uppercase tracking-widest text-gray-500">Connect</span>
            </div>
            
            <div className="flex flex-col gap-4">
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="group flex items-center gap-4 text-white hover:text-[#ff6600] transition-colors"
              >
                <div className="flex h-10 w-10 items-center justify-center border border-gray-700 group-hover:border-[#ff6600] bg-gray-900">
                  <Github className="h-5 w-5" />
                </div>
                <span className="brand-font font-bold uppercase tracking-wider text-lg">GITHUB</span>
              </a>
              
              <a
                href="mailto:contact@kmeanstudio.com"
                className="group flex items-center gap-4 text-white hover:text-[#ff6600] transition-colors"
              >
                <div className="flex h-10 w-10 items-center justify-center border border-gray-700 group-hover:border-[#ff6600] bg-gray-900">
                  <Mail className="h-5 w-5" />
                </div>
                <span className="brand-font font-bold uppercase tracking-wider text-lg">GMAIL</span>
              </a>
            </div>
          </div>

          {/* Column 4: Rotating Info Block */}
          <div className="flex flex-col lg:items-end">
            <div className="w-full max-w-sm border border-gray-800 bg-gray-900/50 p-6 backdrop-blur-sm min-h-[140px] flex flex-col justify-center transition-all duration-500">
              <div className={`transition-opacity duration-500 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
                <div className="flex items-center gap-2 mb-4 text-[#ff6600]">
                  {slides[currentSlide].icon}
                  <span className="brand-font font-bold uppercase tracking-wider animate-pulse">
                    {slides[currentSlide].title}
                  </span>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {slides[currentSlide].content}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-xs font-bold uppercase tracking-widest text-gray-600">
            © {new Date().getFullYear()} K-MEAN STUDIO. ALL RIGHTS RESERVED.
          </div>
          <div className="hidden md:flex gap-2">
            {slides.map((_, index) => (
              <div 
                key={index}
                className={`h-2 w-2 transition-colors duration-300 ${index === currentSlide ? 'bg-[#ff6600]' : 'bg-gray-800'}`}
              ></div>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
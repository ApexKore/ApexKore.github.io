import React, { useState, useEffect } from 'react';

interface IntroOverlayProps {
  onEnter: () => void;
  isExiting: boolean;
}

const IntroOverlay: React.FC<IntroOverlayProps> = ({ onEnter, isExiting }) => {
  const [timeLeft, setTimeLeft] = useState(8);

  useEffect(() => {
    // Automatically enter when countdown hits 0
    if (timeLeft === 0) {
      onEnter();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onEnter]);

  return (
    <div 
      className={`fixed inset-0 z-50 flex items-center justify-center bg-black transition-all duration-[800ms] ease-out ${
        isExiting ? 'opacity-0 blur-[20px] pointer-events-none' : 'opacity-100 blur-0'
      }`}
    >
      {/* Countdown Timer & Manual Enter */}
      <div className="absolute top-6 right-6 z-20 flex flex-col items-end gap-2">
        <span className="brand-font text-6xl font-black text-white opacity-80">
          0{timeLeft}
        </span>
        <button 
          onClick={onEnter}
          className="text-xs font-bold uppercase tracking-widest text-[#ff6600] hover:text-white transition-colors cursor-pointer"
        >
          [ ENTER STUDIO ]
        </button>
      </div>

      {/* Video Container */}
      <div className="relative h-screen w-screen bg-black overflow-hidden">
        {/* 
          Using 'poster' to show logo immediately before video plays. 
          'object-cover' ensures full screen.
        */}
        <video 
          id="intro-video"
          autoPlay 
          muted 
          playsInline 
          poster="logo.png"
          className="h-full w-full object-cover"
          style={{ width: '100vw', height: '100vh', objectFit: 'cover' }}
          onEnded={onEnter}
        >
          <source src="intro.mp4" type="video/mp4" />
          {/* Fallback if video fails */}
          <img src="logo.png" alt="K-Mean Studio" className="h-full w-full object-cover" />
        </video>
      </div>
    </div>
  );
};

export default IntroOverlay;
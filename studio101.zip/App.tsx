import React, { useState, useEffect } from 'react';
import IntroOverlay from './components/IntroOverlay';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Marquee from './components/Marquee';
import About from './components/About';
import Projects from './components/Projects';
import Vision from './components/Vision';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [hasEntered, setHasEntered] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  const handleEnter = () => {
    setIsExiting(true);
    setTimeout(() => {
      setHasEntered(true);
    }, 1000);
  };

  // Lock scroll until the user has fully entered the site
  useEffect(() => {
    if (!hasEntered) {
      document.body.style.overflow = 'hidden';
    } else {
      // Removing the inline style allows the CSS stylesheet to take over
      document.body.style.overflow = '';
    }
    
    // Cleanup function
    return () => {
      document.body.style.overflow = '';
    };
  }, [hasEntered]);

  return (
    <div className="relative min-h-screen w-full bg-white text-black selection:bg-[#ff6600] selection:text-white">
      {/* Intro Overlay */}
      <IntroOverlay onEnter={handleEnter} isExiting={isExiting} />

      {/* Main Content */}
      <div className={`${hasEntered ? 'opacity-100' : 'opacity-0'} transition-opacity duration-1000 delay-500`}>
        <Navbar />
        <main>
          <Hero />
          <Marquee />
          <About />
          <Projects />
          <Vision />
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default App;
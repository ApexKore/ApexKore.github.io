import { Project, NavItem } from './types';

export const BRAND_COLORS = {
  orange: '#ff6600',
  black: '#000000',
  white: '#ffffff',
};

export const PROJECTS: Project[] = [
  {
    id: 'p1',
    title: 'APEX KORE',
    description: 'The foundation of the next generation. Highly optimized, scalable backend infrastructure designed for high-frequency data processing and low-latency response times.',
    status: 'Coming Soon',
    techStack: ['Rust', 'gRPC', 'Kafka', 'Kubernetes'],
    image: 'https://picsum.photos/800/600?random=1',
  },
  {
    id: 'p2',
    title: 'VELOCITY ENGINE',
    description: 'A custom rendering pipeline built for manga-style aesthetics in real-time web applications. Features hard-edge shadow mapping and halftone shader generation.',
    status: 'Beta',
    techStack: ['WebGL', 'React', 'GLSL', 'Three.js'],
    image: 'https://picsum.photos/800/600?random=2',
  },
  {
    id: 'p3',
    title: 'SYNTHETIC MIND',
    description: 'Autonomous agent framework for generating procedural narrative structures. Leveraging LLMs to create dynamic, branching storylines on the fly.',
    status: 'Concept',
    techStack: ['Python', 'PyTorch', 'FastAPI'],
    image: 'https://picsum.photos/800/600?random=3',
  }
];

export const NAV_LINKS: NavItem[] = [
  { label: 'ABOUT', href: '#about' },
  { label: 'WORKS', href: '#projects' },
  { label: 'VISION', href: '#vision' },
];